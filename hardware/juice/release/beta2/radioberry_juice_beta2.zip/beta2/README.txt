Radioberry juice beta 2 Release

## Project Description

The radioberry is a software defined amateur radio; which can be plugged in to this Juice board.

The USB-C connection can be used to connect the board to a host computer.


The folders present in this zip archive contains files for fabrication of the Radioberry juice. 


## Folders

- scheme
	contains the scheme.
- pcb 
	contains the gerber pcb files and drill file.
- position
	position files top and bottom
- bom
	contains the BOM.
- images
	some images to show how the beta 1 was built; especially added for showing the large connector orientation.

## Assembly
!!!! If things are not clear please ask!

See the pictures in the image folder for the J5 2x20pins connector.

	

## Contact
Please contact Johan, PA3GSB pa3gsb@gmail.com with any questions.



